// Supabase removed - authentication stripped out
